package com.example.api124;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText et_unm,et_pass;
    private Button submit_btn;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_unm = findViewById(R.id.editTextTextUnm);
        et_pass = findViewById(R.id.editTextTextPass);
        submit_btn = findViewById(R.id.btn_submit);
        progressDialog = new ProgressDialog(this);

        submit_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(et_unm.getText().toString()) || TextUtils.isEmpty(et_pass.getText().toString()))
                {
                    Toast.makeText(MainActivity.this, "Please Fill_up The Form....", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    //Proceed to Login
                    login();
                }

            }
        });
    }

    public void login()
    {
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername(et_unm.getText().toString());
        loginRequest.setPassword(et_pass.getText().toString());

        Call<LoginResponse> loginResponseCall = ApiClient.getUserService().userLogin(loginRequest);

        loginResponseCall.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                progressDialog.dismiss();
                if (response.isSuccessful())
                {
                    Toast.makeText(MainActivity.this, "Login Successfully...", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Login Failed...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(MainActivity.this, "Throwable :- " + t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}