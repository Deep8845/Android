package com.example.api124;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserService {

    @POST("/api/authenticate") // Root URL.....
    Call<LoginResponse> userLogin(@Body LoginRequest loginRequest);

}
