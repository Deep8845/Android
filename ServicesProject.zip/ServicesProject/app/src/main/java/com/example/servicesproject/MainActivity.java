package com.example.servicesproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.media.audiofx.BassBoost;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button startt,stop;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startt = findViewById(R.id.btn_start);
        stop = findViewById(R.id.btn_end);
        tv = findViewById(R.id.textView);

        startt.setOnClickListener(this);
        stop.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        if (view == startt)
        {
            startService(new Intent(this, MyService.class));
            tv.setText("Service Start......");
        }
        else if (view == stop)
        {
            stopService(new Intent(this, MyService.class));
            tv.setText("Service Stop......");
        }
    }
}