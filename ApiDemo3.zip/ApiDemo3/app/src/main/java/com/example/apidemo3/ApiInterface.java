package com.example.apidemo3;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiInterface {
    @GET("posts")
    Call<List<PostPojo>> getposts();

    @POST("posts")
    Call<PostPojo> saveUsers(@Body PostPojo postPojo);
}
