package com.example.apidemo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity2 extends AppCompatActivity {
    TextInputEditText uid,id,tit,body;
    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        uid = findViewById(R.id.tedUid);
        id = findViewById(R.id.tedId);
        tit = findViewById(R.id.tedTitle);
        body = findViewById(R.id.tedBody);
        add = findViewById(R.id.btn_add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData(create());
            }
        });

    }

    public PostPojo create()
    {
        PostPojo postPojo = new PostPojo();
        postPojo.setTitle(tit.getText().toString());
        postPojo.setBody(body.getText().toString());

        return postPojo;
    }

    public void saveData(PostPojo postPojo)
    {
        Call<PostPojo> postPojoCall = RetrofitInstance.getUserService().saveUsers(postPojo);
        postPojoCall.enqueue(new Callback<PostPojo>() {
            @Override
            public void onResponse(Call<PostPojo> call, Response<PostPojo> response) {
                if (response.isSuccessful())
                {
                    Toast.makeText(MainActivity2.this, "Inserted...", Toast.LENGTH_SHORT).show();
                    uid.setText("");
                    id.setText("");
                    tit.setText("");
                    body.setText("");
                    add.setText("");
                }
                else
                {
                    Toast.makeText(MainActivity2.this, "Not Inserted....", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<PostPojo> call, Throwable t) {
                Toast.makeText(MainActivity2.this, "Some Problem hear..." + t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}