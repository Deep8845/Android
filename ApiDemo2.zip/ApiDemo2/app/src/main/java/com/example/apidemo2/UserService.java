package com.example.apidemo2;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserService {
    @POST("api/authenticate")
    Call<UserResponse> saveUsers(@Body UserRequest userRequest);
}
