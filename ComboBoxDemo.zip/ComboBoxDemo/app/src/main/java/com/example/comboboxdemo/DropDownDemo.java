package com.example.comboboxdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DropDownDemo extends AppCompatActivity{
    AutoCompleteTextView sp1;
    TextView tv2;
    CheckBox c1;
//    String[] language = { "Android", "Java", "PHP", "ASP .Net"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drop_down_demo);
        String[] language = { "Android", "Java", "PHP", "ASP .Net"};

//        List<String> language = new ArrayList<>();
//        language.add(0,"Select Language");
//        language.add("Android");
//        language.add("Java");
//        language.add("PHP");
//        language.add("ASP .Net");

        sp1 = findViewById(R.id.autoCompleteTextView);
        tv2 = findViewById(R.id.tv_drop);
        c1 = findViewById(R.id.chb);





        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), R.layout.items,language);
        adapter.setDropDownViewResource(R.layout.items);
        sp1.setAdapter(adapter);
        



        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            //find the clicked item position and get the value of selected item
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                String value = adapterView.getItemAtPosition(i).toString();
                Toast.makeText(DropDownDemo.this, value, Toast.LENGTH_SHORT).show();
////                Toast.makeText(DropDownDemo.this, value, Toast.LENGTH_SHORT).show();
//                tv1.setText((String)adapterView.getItemAtPosition(i));
//                String value = adapterView.getItemAtPosition(i).toString();
//                Toast.makeText(DropDownDemo.this, value, Toast.LENGTH_SHORT).show();

//                sp1.setText(sp1.getSelectedItem().to);



            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }


}