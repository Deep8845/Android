package com.example.comboboxdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
    CheckBox cb1,cb2,cb3,cb4;
    Button submit;
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        cb1 = findViewById(R.id.chb1);
        cb2 = findViewById(R.id.chb2);
        cb3 = findViewById(R.id.chb3);
        cb4 = findViewById(R.id.chb4);
        submit = findViewById(R.id.btn_submit);
        tv1 = findViewById(R.id.tv_output);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StringBuilder result = new StringBuilder();
                result.append("Selected Language:");

                if (cb1.isChecked())
                {
                    result.append("\n"+cb1.getText());
                }
                if (cb2.isChecked())
                {
                    result.append("\n"+cb2.getText());
                }
                if (cb3.isChecked())
                {
                    result.append("\n"+cb3.getText());
                }
                if (cb4.isChecked())
                {
                    result.append("\n"+cb4.getText());
                }

                tv1.setText(result.toString());

                Intent intent = new Intent(MainActivity.this,DropDownDemo.class);
                startActivity(intent);
                finish();

            }
        });

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,DropDownDemo.class);
                startActivity(intent);
                finish();
            }
        });
    }

}