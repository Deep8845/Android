package com.example.activity_pro;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    String message = "Android : ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(message, "The onCreate() Event");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(message, "The onStart() Event");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(message, "The onResume() Event");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(message, "The onPause() Event");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(message, "The onStop() Event");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(message, "The onDestroy() Event");
    }

}