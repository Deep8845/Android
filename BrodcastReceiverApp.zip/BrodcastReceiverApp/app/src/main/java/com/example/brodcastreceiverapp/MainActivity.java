package com.example.brodcastreceiverapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter intentFilter = new IntentFilter("com.deep.myBroadcastMessage");
        MyBroadcastReceiver obj = new MyBroadcastReceiver();
        registerReceiver(obj,intentFilter);


        IntentFilter inFilter = new IntentFilter("android.intent.action.BATTERY_LOW");
        MyBroadcastReceiver ob = new MyBroadcastReceiver();
        registerReceiver(ob,inFilter);

        IntentFilter iFilter = new IntentFilter("android.intent.action.ACTION_POWER_CONNECTED");
        MyBroadcastReceiver o = new MyBroadcastReceiver();
        registerReceiver(o,iFilter);
    }
}