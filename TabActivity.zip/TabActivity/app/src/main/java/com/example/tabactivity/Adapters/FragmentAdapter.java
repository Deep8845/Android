package com.example.tabactivity.Adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.tabactivity.Fragments.Calls_Frag;
import com.example.tabactivity.Fragments.Chat_Frag;
import com.example.tabactivity.Fragments.Status_Frag;

public class FragmentAdapter extends FragmentPagerAdapter {
    public FragmentAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    public FragmentAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {

        switch (position)
        {
            case 0: return new Chat_Frag();
            case 1: return new Status_Frag();
            case 2: return new Calls_Frag();
            default: return new Chat_Frag();
        }

    }

    @Override
    public int getCount() {
        return 3; // there is Three Fragment we use so return 3
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;

        if (position == 0)
        {
            title = "Chats";
        }
        else if (position == 1)
        {
            title = "Status";
        }
        else if (position == 2)
        {
            title = "Call";
        }

        return title;
    }
}
